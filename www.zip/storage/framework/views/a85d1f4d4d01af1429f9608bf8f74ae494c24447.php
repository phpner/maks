<div class="row ajaxItems">
    <?php if(isset($items)): ?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col md-12 items clearfix">
                <?php if(isset($item->img_link)): ?>
                    <div class="thumbnail">
                        <a data-title="<?php echo e($item->title); ?>" data-lightbox="roadtrip" href="/uploads/<?php echo e($item->img_link); ?>">
                            <img src="/uploads/_thumb_<?php echo e($item->img_link); ?>" alt="<?php echo e($item->title); ?>">
                        </a>
                    </div>
                <?php endif; ?>
                <div class="title"><h4><?php echo e($item->title); ?></h4></div>
                <div class="description"><h5><?php echo $item->description; ?></h5></div>
                    <?php if(isset($item->price)): ?>
                <div class="delivery"><span class="price"><?php echo e($item->price); ?></span></div>
                        <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div id="pagination">
        <?php echo e($items->render()); ?>

    </div>
    </div>

</div>
