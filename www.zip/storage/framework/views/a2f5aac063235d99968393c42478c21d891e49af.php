<div class="row">
    <?php if(isset($items)): ?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col md-12 items clearfix">
                <div class="thumbnail">
                    <a href="/uploads/<?php echo e($item->img_link); ?>">
                        <img src="/uploads/_thumb_<?php echo e($item->img_link); ?>" alt="">
                    </a>
                </div>
                <div class="title"><h4><?php echo e($item->title); ?></h4></div>
                <div class="description"><h5><?php echo e($item->description); ?></h5></div>
                <div class="delivery"><h5><img src="/img/delivery.png" alt="">&nbsp;<?php echo e($item->delivery); ?></h5></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div id="pagination">
        <?php echo e($items->render()); ?>

    </div>
</div>
