<div class="jsonUsers">
    <table>
        <thead>
        <tr>
        <th>Имя</th>
        <th>Email</th>
        <th>Пароль</th>
        <th>Edit</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($user->name); ?></td>  <td> <?php echo e($user->email); ?> </td>  <td> ********* </td>
                <td>
                    <a href="#"><span class="glyphicon glyphicon-pencil edit"></span></a>
                <a href=""><span class="glyphicon glyphicon-remove "></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
</div>
<div class="col-md-12 text-center">
    <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#reg">
        Добавить
    </button>
</div>

<div class="modal fade" id="reg" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="myModalLabel">Загрузка файлов</h4>
            </div>
            <div class="modal-body">

                <?php echo $__env->make('admin.regFromSettings', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
        </div>
    </div>
</div>