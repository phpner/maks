<?php $__env->startSection('content'); ?>
   <?php if(isset($items)): ?>
       <div class="status">
           <h2 class="title">Всего товаров: <?php echo e(isset($count) ? $count : 0); ?> </h2>
       <ul class="allItems">
       <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li>
                   <a href="admin/del_item/<?php echo e($item->id); ?>">
                        <span class="glyphicon glyphicon-remove delete"></span>
                   </a>
                   <a  href="admin/edit_item/<?php echo e($item->id); ?>">
                       <span class="glyphicon glyphicon-pencil edit"> </span>
                   </a>

                   <a class="text" href="admin/edit_item/<?php echo e($item->id); ?>"><?php echo e($item->title); ?></a>
                  </li>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </ul>
           <?php echo e($items->links()); ?>

       </div>
   <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(function(){
            //Confirm delete
        $('.delete').on('click',function(e){

           var res = confirm('Удалисть ?');

           (!res) ? e.preventDefault() : '' ;
        });

        //Selected
        $('.delete').on({
            mouseenter:function(){
           $(this).closest('li').find('.text').css('color','red');
        },
            mouseleave: function(){
                $(this).closest('li').find('.text').css('color','');
            },
        });
        })
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>