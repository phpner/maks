<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<meta property="og:image" content="http://maks.fermaeko.com/img/header_for_share.jpg" />
<meta property="og:image:width" content="604" />
<meta property="og:image:height" content="604" />

<meta name="description" content="Пакеты со склада оптом Киев"/>
<meta name="robots" content="noodp"/>
<link rel="canonical" href="http://maks.fermaeko.com" />
<meta property="og:locale" content="ru_RU" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Пакеты со склада оптом Киев" />
<meta property="og:description" content="Пакеты со склада оптом  по низкой цене !" />
<meta property="og:url" content="http://maks.fermaeko.com" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:description" content="Пакеты со склада оптом  Киев по низкой цене !" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <script src="/js/jquery.min.js"></script>
    <script src="/js/lightbox.js" ></script>

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
    <?php echo $__env->yieldContent('script'); ?>
</head>
<body>
<div id="app">
    <?php echo $__env->make('.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="/js/jquery.magnific-popup.min.js"></script>

</body>
</html>
