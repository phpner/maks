<div class="laradrop-container" id="laradrop-container-[[uid]]" >
    
    <button type="button" class="btn btn-default btn-add-folder"><?php echo trans('laradrop::app.addFolder'); ?></button>
    <button type="button" class="btn btn-default btn-add-files"><?php echo trans('laradrop::app.uploadFiles'); ?></button>
    <button type="button" class="btn btn-success start" style="display:none;" ><?php echo trans('laradrop::app.startUpload'); ?></button>
       
    <div class="laradrop-breadcrumbs-container"></div>    
    <hr>
    
    <div class="laradrop-previews" ></div>
    <div class="laradrop-body" ></div>
</div>