<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <form action="/get" method="post">
                <div id="select">
                <select name="cate" >
                    <option value="0">Все</option>
                    <option value="1">пакет майка</option>
                    <option value="2">фасовочные пакеты</option>
                    <option value="3">мусорные пакеты</option>
                </select>
                </div>
            </form>
        </div>
        <div class="row ajaxItems">
            <?php if(isset($items)): ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col md-12 items clearfix">
                        <?php if(isset($item->img_link)): ?>
                            <div class="thumbnail">
                                <a data-title="<?php echo e($item->title); ?>"  data-lightbox="roadtrip" href="/uploads/<?php echo e($item->img_link); ?>">
                                <img src="/uploads/_thumb_<?php echo e($item->img_link); ?>" alt="<?php echo e($item->title); ?>">
                                </a>
                            </div>
                        <?php endif; ?>
                        <div class="title"><h4><?php echo e($item->title); ?></h4></div>
                        <div class="description"><h5><?php echo $item->description; ?></h5></div>
                            <?php if(isset($item->price)): ?>
                        <div class="delivery"><span class="price"><?php echo e($item->price); ?></span></div>
                                <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <div id="pagination">
            <?php echo e($items->render()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            var sel;

            $('#select select').on('change', function () {
                var id = $(this).val();
                 window.sel = $(this).val();
                $.ajax({
                    url: '/get/select',
                    method: "get",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {'id': id, }
                }).done(function (data){
                    $('.ajaxItems').html(data);
                    location.hash = '';
                }).fail(function (jqXHR, exception) {
                });
            });

           $(document).on('click','#pagination_select .pagination a',function (e){
                e.preventDefault();

                var cat = window.sel;
                var id = $(this).attr('href').split('page=')[1];
                $.ajax({
                    url:'/get/select?page=' + id +'&id='+ cat
                }).done(function (data){

                    $('.ajaxItems').html(data);

                });
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>