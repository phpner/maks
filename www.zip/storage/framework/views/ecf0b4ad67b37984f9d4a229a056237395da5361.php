<?php if(isset($messages)): ?>
    <?php echo e($messages->messages()->first('email')); ?> <br>
    <?php echo e($messages->messages()->first('password')); ?>

<?php endif; ?>