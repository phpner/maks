<footer>
    <nav class="row menu footer">
       <div class="col-md-4"><span id="email"><img src="/img/email.png" alt=""> spaket17@gmail.com</span></div>
            <span id="phone">
                <div class="col-md-4"><img src="/img/phone-call.png" alt=""> 063-622-82-25</div>
                <div class="col-md-4"> <img src="/img/clock.png" alt=""> режим: 24/7</div>
            </span>
        <div class="row power">
            power by <a href="http://phpner.in.ua">phpner</a>
        </div>
        <div class="enter"><a href="/login">Вход</a></div>
    </nav>
</footer>