<div class="container-fluid">
    <div class="row header">
        <img class="header-bg" src="/img/header.png" alt="">
        <img  class="flower-top" src="/img/flower-top.png" alt="">
        <img class="flower-bottom" src="/img/flower-bottom.png" alt="">
        <nav class="row menu">
            <span id="email"><img src="/img/email.png" alt=""> spaket17@gmail.com</span>
            <span id="phone"><img src="/img/phone-call.png" alt=""> 063-622-82-25 <span class="hidden-xs">
                    <img src="/img/clock.png" alt=""> режим: 24/7
                </span>
            </span>
        </nav>
        <div class="row">
            <p class="header-text">
                <img id="logo" src="/img/logo.jpg" alt="">
            </p>
        </div>

        <button>
            <a href="/doc/pricelist.docx"><span id="s">Скачать</span> <span id="p">прайс лист</span></a>
        </button>


    </div>
    <div class="row text-bottom">
        <ol class="col-md-6 col-md-offset-4 col-xs-6 col-xs-offset-3">
        <li>Специальные цены для крупного опта.</li>
            <li>Изготовление пакетов с логотипом.</li>
            <li>Доставка по всей Украине, по  Киеву бесплатная.</li>
            <ol>
    </div>
</div>